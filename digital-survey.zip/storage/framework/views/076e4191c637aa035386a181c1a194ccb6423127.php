<?php $__env->startSection('content'); ?>
<!--begin::Row-->
<div class="row gy-5 g-xl-8">

</div>
<!--end::Row-->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/riski/Desktop/Data/Codingan/Projekan/Digital Survey Jingga Teknologi/digital-survey/resources/views/dashboard/register-polis/index.blade.php ENDPATH**/ ?>