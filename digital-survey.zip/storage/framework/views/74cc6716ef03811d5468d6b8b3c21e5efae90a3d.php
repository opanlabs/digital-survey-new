<?php $__env->startSection('content'); ?>
    <div class="card">
        
        <div class="card-header">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bolder fs-3 mb-1">List User</span>
            </h3>
        </div>
        <div class="card-body">
            <?php echo e($dataTable->table(['class' => 'table table-striped gy-7 gs-7'])); ?>

        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/riski/Desktop/Data/Codingan/Projekan/Digital Survey Jingga Teknologi/digital-survey/resources/views/dashboard/users/index.blade.php ENDPATH**/ ?>