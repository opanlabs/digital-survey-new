<?php $__env->startSection('content'); ?>
    <div class="card">
        
        <div class="card-header">
            <h3 class="card-title align-items-start flex-column">
                <span class="card-label fw-bolder text-dark">List Register Risk Survey</span>
            </h3>
            <div class="card-toolbar">
                <a href="#" data-bs-toggle="modal" data-bs-target="#kt_modal_new_card" class="btn btn-primary">Add Register Risk Survey</a>
            </div>
        </div>
        <div class="card-body">
            <?php echo e($dataTable->table(['class' => 'table table-striped gy-7 gs-7'])); ?>

        </div>
        <!-- modal add register risk survey -->
        <div class="modal fade" id="kt_modal_new_card" tabindex="-1" aria-hidden="true">
            <form action='<?php echo e(route('register-survey.create', ['id' => Auth::user()->id_user])); ?>' method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Add Register Risk Survey</h2>
                            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                            <form id="kt_modal_new_card_form" class="form" action="#">
                                <div class="row">
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Costumer Name</span>
                                            </label>
                                            <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="customer_name" value="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Phone Number</span>
                                            </label>
                                            <input type="number" class="form-control form-control-solid <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="phone_number" value="" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Email Address</span>
                                            </label>
                                            <input type="email" class="form-control form-control-solid <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="email" value="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Vehicle Brands</span>
                                            </label>
                                            <select class="form-select form-select-solid <?php $__errorArgs = ['id_vehicle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required data-control="select2" name="id_vehicle" data-placeholder="Select an option" data-hide-search="true">
                                                <option></option>
                                                <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($br->id_vehicle); ?>"><?php echo e($br->nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Vehicle Type</span>
                                            </label>
                                            <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="type" value="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Year Vehicle</span>
                                            </label>
                                            <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="year" value="" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Plat No</span>
                                            </label>
                                            <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['plat_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="plat_no" value="" />
                                        </div>
                                    </div>
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Surveyor Name</span>
                                            </label>
                                            <input type="text" class="form-control form-control-solid <?php $__errorArgs = ['surveyor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required placeholder="" name="surveyor" value="" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 fv-row">
                                        <div class="d-flex flex-column mb-7 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                                <span>Branch</span>
                                            </label>
                                            <select class="form-select form-select-solid <?php $__errorArgs = ['id_branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required data-control="select2" name="id_branch" data-placeholder="Select an option" data-hide-search="true">
                                                <option></option>
                                                <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($br->id_branch); ?>"><?php echo e($br->province_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button data-bs-dismiss="modal" type="reset" id="kt_modal_new_card_cancel" class="btn btn-light me-3">Cancel</button>
                            <button type="submit" id="kt_modal_new_card_submit" class="btn btn-primary">Submit
                            </button>
                        </div>
                        
                    </div>
                </div>
            </form>
        </div>
        <!-- modal schedule -->
        <div class="modal fade editSchedule" tabindex="-1" id="kt_schedule">
            <form action='<?php echo e(route('register-survey.schedule')); ?>' method="post" id="form-update" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Create Schedule Risk Survey</h5>
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
                                <span class="svg-icon svg-icon-2x"></span>
                            </div>
                            <!--end::Close-->
                        </div>
                        <div class="modal-body">
                                <div class="d-flex flex-column mb-7 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-bold form-label mb-2">
                                        <span>Select date</span>
                                    </label>
                                    <input class="form-control form-control-solid <?php $__errorArgs = ['survey_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required name="survey_date" placeholder="Pick date" id="kt_datepicker_10"/>
                                    <?php $__errorArgs = ['survey_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
            
                        <div class="modal-footer">
                            <button data-bs-dismiss="modal" type="reset" id="kt_modal_new_card_cancel" class="btn btn-light me-3">Cancel</button>
                            <button type="submit" id="kt_modal_new_card_submit" class="btn btn-primary">
                                Create
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- modal delete -->
        <div class="modal fade deleteSurvey" id="kt_modal_delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeLg" aria-hidden="true">
            <form action='<?php echo e(route('register-survey.deleteSurvey')); ?>' method="post" id="form-update" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="flex-column">
                                    <div class="modal-header border-0 text-center mt-5 justify-content-center">
                                        <i class="bi bi-x-circle fs-5x text-danger"></i>
                                    </div>						
                                    <h4 class="modal-title w-100 text-center">Are you sure?</h4>
                                </div>
                                <div class="modal-body text-center">
                                    <p>Do you really want to delete these records?<br> This process cannot be undone.</p>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button data-bs-dismiss="modal" type="reset" id="kt_modal_new_card_cancel" class="btn btn-light btn-sm">Cancel</button>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
            </form>
        </div>
        <!-- modal schedule report -->
        <div class="modal fade reportSurvey" id="kt_report" tabindex="-1" aria-hidden="true">
            <form action='<?php echo e(route('register-survey.report')); ?>' method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <input type="hidden" name="id">
                <div class="modal-dialog modal-dialog-centered mw-1000px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Realtime survey report</h2>
                            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                                <div class="card pt-4 mb-xl-9">
                                    <div id="kt_customer_view_payment_method" class="card-body pt-0">
                                        <div class="d-flex flex-wrap py-2">
                                            <div class="flex-equal me-5">
                                                <table class="table table-flush fw-bold gy-2">
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">No Register</td>
                                                        <td class="text-gray-800" id="no_register"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Costumer name</td>
                                                        <td class="text-gray-800" id="customer_name"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Vehicle Brand</td>
                                                        <td class="text-gray-800" id="vehicle_brand_report"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Vehicle Type</td>
                                                        <td class="text-gray-800" id="vehicle_type_report"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Year</td>
                                                        <td class="text-gray-800" id="year_reporting_survey"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Plat No</td>
                                                        <td class="text-gray-800" id="plat_no"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="flex-equal">
                                                <table class="table table-flush fw-bold gy-2">
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Surveyor</td>
                                                        <td class="text-gray-800" id="surveyor"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Survey Date</td>
                                                        <td class="text-gray-800" id="survey_date"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Location</td>
                                                        <td class="text-gray-800" id="location"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Register Date</td>
                                                        <td class="text-gray-800" id="register_date">08/10/2022</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="separator separator-dashed mt-5 mb-10"></div>
                                        <!-- list vehicle -->
                                        <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="py-0" data-kt-customer-payment-method="row">
                                                <div class="py-3 d-flex flex-stack flex-wrap">
                                                    <div class="d-flex align-items-center collapsible rotate" data-bs-toggle="collapse" href="#kt_customer_view_payment_method_<?php echo e($key); ?>" role="button" aria-expanded="false" aria-controls="kt_customer_view_payment_method_<?php echo e($key); ?>">
                                                        <div class="me-3 rotate-90">
                                                            <span class="svg-icon svg-icon-3">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="currentColor" />
                                                                </svg>
                                                            </span>
                                                        </div>
                                                        <img class="me-10" />
                                                        <div class="me-3">
                                                            <div class="d-flex align-items-center">
                                                                <div class="text-gray-800 fw-bolder"><?php echo e($item->type_nama); ?></div>
                                                            </div>
                                                            <div class="text-muted">Harap Isi </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="kt_customer_view_payment_method_<?php echo e($key); ?>" class="collapse <?php echo e($key === 0 ? 'show' : ''); ?> fs-6 ps-10" data-bs-parent="#kt_customer_view_payment_method">
                                                    <div class="d-flex flex-wrap py-5">
                                                        <div class="d-flex flex-wrap py-5">
                                                            <!-- content -->
                                                            <div class="table-responsive">
                                                                <table class="table gs-7 gy-7 gx-7">
                                                                 <thead>
                                                                  <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
                                                                   <th>No</th>
                                                                   <th>Part</th>
                                                                   <th>Non Standard</th>
                                                                   <th>Description</th>
                                                                   <th>Action</th>
                                                                  </tr>
                                                                 </thead>
                                                                 <tbody>
                                                                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keychild => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($sub->id_part); ?></td>
                                                                        <td><?php echo e($sub->part_nama); ?></td>
                                                                        <td>
                                                                            <input type="checkbox" value="true" name="isStandard[<?php echo e($sub->id_part); ?>][value]" />
                                                                            <input type="hidden" value="<?php echo e($sub->id_part); ?>" name="isStandard[<?php echo e($sub->id_part); ?>][id_part]" />
                                                                        </td>
                                                                        <td>
                                                                            <input type="text" value="<?php echo e($sub->description); ?>" name="description[<?php echo e($sub->id_part); ?>][value]" />
                                                                            <input type="hidden" value="<?php echo e($sub->id_part); ?>" name="description[<?php echo e($sub->id_part); ?>][id_part]" />
                                                                        </td>
                                                                        <td>
                                                                            <input class="photo" type="file" name="photo[<?php echo e($sub->id_part); ?>][value]" accept=".jpg, .jpeg">
                                                                            <input type="hidden" value="<?php echo e($sub->id_part); ?>" name="photo[<?php echo e($sub->id_part); ?>][id_part]" />
                                                                        </td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 </tbody>
                                                                </table>
                                                               </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="separator separator-dashed"></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="separator separator-dashed"></div>

                                        <!-- end list vehicle -->

                                        <div class="flex-equal mt-10">
                                            <table class="table table-flush fw-bold gy-1">
                                                <tr>
                                                    <td class="text-muted min-w-125px w-125px">Upload Video Report</td>
                                                    <td class="text-gray-800">
                                                        <input type="file" name="videoUpload" accept=".mp4, .mkv , .mov , .avi">
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button data-bs-dismiss="modal" type="reset" id="kt_modal_new_card_cancel" class="btn btn-light me-3">Cancel</button>
                            <button type="submit" id="kt_modal_new_card_submit" class="btn btn-primary">Save
                            </button>
                        </div>
                        
                    </div>
                </div>
            </form>
        </div>
        <!-- modal schedule report view -->
        <div class="modal fade reportSurveyView" id="kt_report_view" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered mw-1000px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Realtime survey report</h2>
                            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="modal-body scroll-y">
                                <div class="card pt-4 mb-xl-9">
                                    <div id="kt_customer_view_payment_method" class="card-body pt-0">
                                        <div class="d-flex flex-wrap py-2">
                                            <div class="flex-equal me-5">
                                                <table class="table table-flush fw-bold gy-2">
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">No Register</td>
                                                        <td class="text-gray-800" id="no_register_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Costumer name</td>
                                                        <td class="text-gray-800" id="customer_name_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Vehicle Brand</td>
                                                        <td class="text-gray-800" id="vehicle_brand_report_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Vehicle Type</td>
                                                        <td class="text-gray-800" id="vehicle_type_report_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Year</td>
                                                        <td class="text-gray-800" id="year_reporting_survey_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Plat No</td>
                                                        <td class="text-gray-800" id="plat_no_view"></td>
                                                    </tr>
                                                </table>
                                                <div class="input-group mb-5">
                                                    <span class="input-group-text" id="basic-addon1">Link</span>
                                                    <input type="text" id="link_report_schedule_view" class="form-control" placeholder="Link Report Video" aria-label="Link Report Video" aria-describedby="basic-addon1"/>
                                                </div>
                                            </div>
                                            <div class="flex-equal">
                                                <table class="table table-flush fw-bold gy-2">
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Surveyor</td>
                                                        <td class="text-gray-800" id="surveyor_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Survey Date</td>
                                                        <td class="text-gray-800" id="survey_date_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Location</td>
                                                        <td class="text-gray-800" id="location_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Register Date</td>
                                                        <td class="text-gray-800" id="register_date_view"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-muted min-w-125px w-125px">Status</td>
                                                        <td class="text-gray-800" id="status_view"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="separator separator-dashed mt-5 mb-10"></div>
                                        <!-- list vehicle -->
                                        <?php $__currentLoopData = $part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="py-0" data-kt-customer-payment-method="row">
                                                <div class="py-3 d-flex flex-stack flex-wrap">
                                                    <div class="d-flex align-items-center collapsible rotate" data-bs-toggle="collapse" href="#kt_customer_view_payment_method_<?php echo e($key); ?>" role="button" aria-expanded="false" aria-controls="kt_customer_view_payment_method_<?php echo e($key); ?>">
                                                        <div class="me-3 rotate-90">
                                                            <span class="svg-icon svg-icon-3">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <path d="M12.6343 12.5657L8.45001 16.75C8.0358 17.1642 8.0358 17.8358 8.45001 18.25C8.86423 18.6642 9.5358 18.6642 9.95001 18.25L15.4929 12.7071C15.8834 12.3166 15.8834 11.6834 15.4929 11.2929L9.95001 5.75C9.5358 5.33579 8.86423 5.33579 8.45001 5.75C8.0358 6.16421 8.0358 6.83579 8.45001 7.25L12.6343 11.4343C12.9467 11.7467 12.9467 12.2533 12.6343 12.5657Z" fill="currentColor" />
                                                                </svg>
                                                            </span>
                                                        </div>
                                                        <img class="me-10" />
                                                        <div class="me-3">
                                                            <div class="d-flex align-items-center">
                                                                <div class="text-gray-800 fw-bolder"><?php echo e($item->type_nama); ?></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="kt_customer_view_payment_method_<?php echo e($key); ?>" class="collapse <?php echo e($key === 0 ? 'show' : ''); ?> fs-6 ps-10" data-bs-parent="#kt_customer_view_payment_method">
                                                    <div class="d-flex flex-wrap py-5">
                                                        <div class="d-flex flex-wrap py-5">
                                                            <!-- content -->
                                                            <div class="table-responsive">
                                                                <table class="table gs-7 gy-7 gx-7">
                                                                 <thead>
                                                                  <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
                                                                   <th>No</th>
                                                                   <th>Part</th>
                                                                   <th>Non Standard</th>
                                                                   <th>Description</th>
                                                                   <th>Action</th>
                                                                  </tr>
                                                                 </thead>
                                                                 <tbody>
                                                                    <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($sub->id_part); ?></td>
                                                                        <td><?php echo e($sub->part_nama); ?></td>
                                                                        <td>
                                                                            <input type="checkbox" disabled id="checkbox_view_<?php echo e($sub->id_part); ?>" value="true"  />
                                                                        </td>
                                                                        <td>
                                                                            <span id="description_view_<?php echo e($sub->id_part); ?>"></span>
                                                                        </td>
                                                                        <td>
                                                                            <div class="image-input image-input-outline me-6" data-kt-image-input="true">
                                                                            <div id="photo_view_<?php echo e($sub->id_part); ?>" class="image-input-wrapper w-125px h-125px" style="background-image: url(<?php echo e(asset('/media/png/avatar-default.png')); ?>)"></div>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                 </tbody>
                                                                </table>
                                                               </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="separator separator-dashed"></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="separator separator-dashed"></div>

                                        <!-- end list vehicle -->
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button data-bs-dismiss="modal" type="reset" id="kt_modal_new_card_cancel" class="btn btn-light me-3">Cancel</button>
                        </div>
                        
                    </div>
                </div>
        </div>  
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo e($dataTable->scripts()); ?>

    <script>
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);

        $.ajaxSetup({
             headers:{
                 'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
             }
         });


        function padTo2Digits(num) {
            return num.toString().padStart(2, '0');
        }

        function formatDate(date) {
        return [
            date.getFullYear(),
            padTo2Digits(date.getMonth() + 1),
            padTo2Digits(date.getDate()),
        ].join('-');
        }

        $("#kt_datepicker_10").flatpickr({
            dateFormat: "Y-m-d",
            disable: [
                {
                    from: "0001-01-01",
                    to: formatDate(yesterday)
                },
            ]
        });
        $(document).on('click','#kt_schedule_mod', function(){
            var id = $(this).data('id');
            $('.editSchedule').find('input[name="id"]').val(id);
        });

        $(document).on('click','#kt_delete_mod', function(){
            var id = $(this).data('id');
            $('.deleteSurvey').find('input[name="id"]').val(id);
        });

        $(document).on('click','#kt_report_mod', function(){
            var id = $(this).data('id');
            $('.reportSurvey').find('input[name="id"]').val(id);
            $.post('<?= route("register-survey.details") ?>',{id:id}, function(data){
                        //  console.log(data.details.register_no);
                        $('#no_register').html(data.details.register_no);
                        $('#customer_name').html(data.details.customer.customer_name);
                        $('#surveyor').html(data.details.surveyor);
                        $('#survey_date').html(data.details.survey_date);
                        $('#location').html(data.details.branch.province_name);
                        $('#register_date').html(data.details.created_at);
                        $('#vehicle_brand_report').html(data.details.vehicle.nama);
                        $('#vehicle_type_report').html(data.details.vehicle.vehicle_type);
                        $('#year_reporting_survey').html(data.details.year);
                        $('#plat_no').html(data.details.plat_no);

            },'json');
        });


        $(document).on('click','#kt_report_view_mod', function(){
            var id = $(this).data('id');
            $('.reportSurveyView').find('input[name="id"]').val(id);
            $.post('<?= route("register-survey.details") ?>',{id:id}, function(data){
                let objDesc = JSON.parse(data.details.descriptionVehicle);
                var resultDesc = Object.keys(objDesc).map((key) => objDesc[key]);

                for (let index = 0; index < resultDesc.length; index++) {
                    const element = resultDesc[index];
                    $(`#description_view_${element.id_part}`).html(element.value);
                }

                let objCheckbox = JSON.parse(data.details.isStandardVehicle);
                var resultCheckbox = Object.keys(objCheckbox).map((key) => objCheckbox[key]);

                for (let index1 = 0; index1 < resultCheckbox.length; index1++) {
                    const element = resultCheckbox[index1];
                    if (element.value === 'true') {
                        $(`#checkbox_view_${element.id_part}`).prop('checked', true);   
                    }
                }
                
                let objPhoto = JSON.parse(data.details.photoVehicle);
                // var resultPhoto = Object.keys(photoVehicle).map((key) => photoVehicle[key]);

                for (let index2 = 0; index2 < objPhoto.length; index2++) {
                    const element = objPhoto[index2];
                    $(`#photo_view_${element.id_part}`).css("background-image", `url(/${element.url ? element.url : 'media/png/avatar-default.png'})`);
                }

                var stats = '';
                if (data.details.status === 'OPEN') {
                    stats = '<a class="btn btn-outline btn-outline-warning btn-active-light-warning btn-sm">Open</a>';
                } else if(data.details.status === 'SCHEDULE') {
                    stats = '<a class="btn btn-outline btn-outline-warning btn-active-light-warning btn-sm">Open</a>';
                } else if(data.details.status === 'DONE') {
                    stats = '<a class="btn btn-outline btn-outline-dark btn-active-light-dark btn-sm">Done</a>';
                }
                
                var url = `${window.location.origin}/${data.details.link_report_zoom}`
                $('#no_register_view').html(data.details.register_no);
                $('#customer_name_view').html(data.details.customer.customer_name);
                $('#surveyor_view').html(data.details.surveyor);
                $('#survey_date_view').html(data.details.survey_date);
                $('#location_view').html(data.details.branch.province_name);
                $('#register_date_view').html(data.details.created_at);
                $('#vehicle_brand_report_view').html(data.details.vehicle.nama);
                $('#vehicle_type_report_view').html(data.details.vehicle.vehicle_type);
                $('#year_reporting_survey_view').html(data.details.year);
                $('#plat_no_view').html(data.details.plat_no);
                $('#status_view').html(stats);
                $('#link_report_schedule_view').val(url);

            },'json');
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/riski/Desktop/Data/Codingan/Projekan/Digital Survey Jingga Teknologi/digital-survey/resources/views/dashboard/register-survey/index.blade.php ENDPATH**/ ?>